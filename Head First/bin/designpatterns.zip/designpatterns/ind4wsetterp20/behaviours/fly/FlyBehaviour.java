package designpatterns.ind4wsetterp20.behaviours.fly;

public interface FlyBehaviour {
    public void fly();
}
