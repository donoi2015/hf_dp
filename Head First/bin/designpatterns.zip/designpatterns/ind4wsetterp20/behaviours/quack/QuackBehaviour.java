package designpatterns.ind4wsetterp20.behaviours.quack;

public interface QuackBehaviour {
    public void quack();
}
