package designpatterns.ind5Observerp57.interfaces;

public interface Observer {
    public void update(float temp, float humidity, float pressure);
}
