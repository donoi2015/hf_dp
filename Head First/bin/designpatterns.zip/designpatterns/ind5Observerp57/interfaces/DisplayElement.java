package designpatterns.ind5Observerp57.interfaces;

public interface DisplayElement {
    public void display();
}
