package designpatterns.ind9Adapterp235;

public interface Turkey {
public void gobble();
public void fly();
}
