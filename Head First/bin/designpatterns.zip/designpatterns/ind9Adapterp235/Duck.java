package designpatterns.ind9Adapterp235;

public interface Duck {
public void quack();
public void fly();
}
