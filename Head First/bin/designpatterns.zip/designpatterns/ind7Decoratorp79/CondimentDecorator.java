package designpatterns.ind7Decoratorp79;

public abstract class CondimentDecorator extends Beverage {
	public abstract String getDescription();
}
