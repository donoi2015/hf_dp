package designpatterns.ind9Combined1p501.ducks;

public class Goose {
    public void honk(){
	System.out.println("Goose Honk");
    }
    @Override
    public String toString() {
	return "Goose";
    }
    
}
