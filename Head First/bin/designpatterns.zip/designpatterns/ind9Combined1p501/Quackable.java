package designpatterns.ind9Combined1p501;

import designpatterns.ind9Combined1p501.observe.Subject;

public interface Quackable extends Subject {
    public void Quack();
}
