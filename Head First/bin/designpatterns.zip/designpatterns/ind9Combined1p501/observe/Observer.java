package designpatterns.ind9Combined1p501.observe;

public interface Observer {
    public void update (Subject duck);
}
