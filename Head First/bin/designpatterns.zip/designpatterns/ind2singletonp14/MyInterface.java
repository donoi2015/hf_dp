package designpatterns.ind2singletonp14;

public interface MyInterface {
    public void doThis();
}
