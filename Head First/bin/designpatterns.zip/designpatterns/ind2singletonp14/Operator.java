package designpatterns.ind2singletonp14;

public interface Operator {
    public int operate (int a, int b);
}
