package designpatterns.ind3strategyp15;

public interface FlyBehaviour {
    public void fly();
}
