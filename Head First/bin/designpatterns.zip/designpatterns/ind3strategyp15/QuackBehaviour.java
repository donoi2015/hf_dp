package designpatterns.ind3strategyp15;

public interface QuackBehaviour {
    public void quack();
}
