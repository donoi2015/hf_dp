package designpatterns.ind6jObserverp64.display;

public interface DisplayElement {
    public void display();
}
